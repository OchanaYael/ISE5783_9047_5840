/**yael ochana 214249047
 * sara mansur 325275840
 * */
package unittests;

import static org.junit.jupiter.api.Assertions.*;
import static primitives.Util.isZero;
import org.junit.jupiter.api.Test;
import geometries.Plane;
import geometries.Tube;
import primitives.Point;
import primitives.Ray;
import primitives.Vector;
/**
 * @author user Yael_ochana, Sara_mansur
 * Unit tests for geometries.Tube class
 */
class TubeTests {

	/**
	 * Test method for {@link geometries.Tube#getNormal(primitives.Point)}.
	 */
	@Test
	void testGetNormal() 
	{
		 // ============ Equivalence Partitions Tests ==============
	      // TC01: There is a simple single test here - using a quad
           Tube t = new Tube(4, new Ray(new Point(3,2,1), new Vector(1,-1,2)));

	      // generate the test result
	      Vector result = t.getNormal(new Point(1, -2, 5));
	      
	      // ensure |result| = 1
	      assertEquals(1, result.length(), 0.00001, "Tube's normal is not a unit vector");
	      
	      //ensure the result is orthogonal to  the edges
	      assertThrows(IllegalArgumentException.class,() ->t.getNormal(new Point(0,5,-5)), "");
	}
	
	/**
	 * Test method for {@link geometries.Tube#findIntersections(primitives.Ray)}.
	 */
	 @Test
	 public void testFindIntersections() {}

}
