/**yael ochana 214249047
 * sara mansur 325275840
 * */
package unittests;

import static org.junit.jupiter.api.Assertions.*;
import static primitives.Util.isZero;

import java.util.List;

import org.junit.jupiter.api.Test;

import geometries.Plane;
import geometries.Polygon;
import primitives.Point;
import primitives.Ray;
import primitives.Vector;

/**
 * @author user Yael_ochana, Sara_mansur
 * Unit tests for geometries.Plane class
 */
class PlaneTests {

	
	/**
	 * Test method for {@link geometries.Plane#getNormal()}.
	 */
	@Test
	  public void testConstructor() 
	{

	      // =============== Boundary Values Tests ==================

	      // TC10:The first and second points are connected
	      assertThrows(IllegalArgumentException.class, //
	                   () -> new Plane(new Point(0, 0, 1), new Point(0, 0, 1), new Point(0, 1, 0))
	                 ,  "Constructed a plane When The first and second points are connected");

	      // TC11: The points are on the same line
	      assertThrows(IllegalArgumentException.class, //
	                   () -> new Plane(new Point(0, 0, 1), new Point(0, 0, 2), new Point(0, 0, 3)),
	                   "Constructed a plane when The points are on the same line ");

	   }


	/**
	 * Test method for {@link geometries.Plane#getNormal(primitives.Point)}.
	 */
	@Test
	public void testGetNormalPoint() 
	{
	      // ============ Equivalence Partitions Tests ==============
	      // TC01: There is a simple single test here - using a quad
		  Point p1= new Point(1,0,0);
		  Point p2= new Point(0,1,0);
		  Point p3= new Point(0,0,1);
	      Plane pla = new Plane( p1, p2,p3);
	      // ensure  there are no exceptions
	      assertDoesNotThrow(() ->pla.getNormal(new Point(1,1,0)), "");
	      // generate the test result
	      Vector result = pla.getNormal(new Point(1, 1, 0));
	      // ensure |result| = 1
	      assertEquals(1, result.length(), 0.00000001, "Plane's normal is not a unit vector");
	      //ensure the result is orthogonal to all the edges
	      assertTrue(isZero(result.dotProduct(p1.subtract(p2))),"Plane's normal is not orthogonal to one of the poin");
	      assertTrue(isZero(result.dotProduct(p2.subtract(p3))),"Plane's normal is not orthogonal to one of the poin");
	      assertTrue(isZero(result.dotProduct(p3.subtract(p1))),"Plane's normal is not orthogonal to one of the poin");
	}
	
	/**
	 * Test method for {@link geometries.Plane#findIntersections(primitives.Ray)}.
	 */
	 @Test
	 public void testFindIntersections() 
	 {
		  Plane plane = new Plane(new Point (0, 0, 1), new Point (0, 2, 0), new Point (1, 0, 0));

	        // ============ Equivalence Partitions Tests ==============
	        // The Ray's here ar not orthogonal and not parallels to the plane
	        // TC01: Ray intersect the plane (1 point)
	        Ray ray = new Ray(new Point(0,-2,0), new Vector(1, 4,-1));
	        assertEquals(List.of(new Point(1,2,-1)), plane.findIntersections(ray));
	        // TC02: Ray does not intersect the plane (0 point)
	        ray = new Ray(new Point(0, 5, 0), new Vector(6,-5,0));
	        assertNull(plane.findIntersections(ray));

	        // =============== Boundary Values Tests ==================
	        // **** Group: Ray is orthogonal to the plane
	        // TC03: Ray start outside  the plane and goes inside the plane (1 point)
	        ray = new Ray(new Point(-2, 0, 0), new Vector(2,1,2));
	        assertEquals(List.of(new Point(-0.6666666666666667, 0.6666666666666666, 1.3333333333333333)),
	                plane.findIntersections(ray));
	        // TC04: Ray start outside  the plane (0 point)
	        ray = new Ray(new Point(-2, 0, 0), new Vector(-1.53,-0.77,-1.53));
	        assertNull(plane.findIntersections(ray));
	        // TC05: Ray start inside the plane (0 point)
	        ray = new Ray(new Point(0, 0, 1), new Vector(1,0.5,2));
	        assertNull(plane.findIntersections(ray));
	        // **** Group: Ray is parallel to the plane
	        // TC06: Ray start inside (0 point)
	        ray = new Ray(new Point(0.67, -2.16, 1.41), new Vector(-1.8,-0.56,2.08));
	        assertNull(plane.findIntersections(ray));
	        // TC07: Ray start outside (0 point)
	        ray = new Ray(new Point(5, 0, 0), new Vector(-0.64,-0.2,0.74));
	        assertNull(plane.findIntersections(ray));
	 }

}
