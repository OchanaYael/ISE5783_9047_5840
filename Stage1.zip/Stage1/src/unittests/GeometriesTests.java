/**
 * 
 */
package unittests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import geometries.Geometries;
import geometries.Plane;
import geometries.Sphere;
import geometries.Triangle;
import primitives.Point;
import primitives.Ray;
import primitives.Vector;

/**
 * the class test for the geometries
 * test the: find intersection
 * @author yael ochana and sara mansur
 */
class GeometriesTests {

	/**
	 * Test method for {@link geometries.Geometries#findIntersections(primitives.Ray)}.
	 */
	 Geometries geo = new Geometries(
	            new Sphere(2, new Point(1, 0.5, 1)),
	            new Plane(
	                    new Point(-2,0,0),
	                    new Point(0,0,4),
	                    new Point(0,-2,0)),
	            new Triangle(
	                    new Point(1,0,0),
	                    new Point(0.1, 0.5, 2.5),
	                    new Point(-2, 0,0)));
	 @Test
	 void testFindIntersections() 
	 {
	     // Initialize Geometries object
	     Geometries geo = new Geometries(
	             new Sphere(2, new Point(1, 0.5, 1)),
	             new Plane(
	                     new Point(-2,0,0),
	                     new Point(0,0,4),
	                     new Point(0,-2,0)),
	             new Triangle(
	                     new Point(1,0,0),
	                     new Point(0.1, 0.5, 2.5),
	                     new Point(-2, 0,0)));
	     
	     // ============ Equivalence Partitions Tests ==============
	     //TC01 ray intersect some geometries
	     Ray ray = new Ray(new Point(0,-10,5), new Vector(1,10.5,-4));
	     assertEquals(3, geo.findIntersections(ray).size());

	     // =============== Boundary Values Tests ==================
	     //TC02 ray intersect all the geometries
	     ray = new Ray(new Point(0,-10,5), new Vector(0,10,-4));
	     assertEquals(4, geo.findIntersections(ray).size());

	     //TC03 ray intersect only one of the geometries
	     ray = new Ray(new Point(0,-10,5), new Vector(0,10,-1));
	     assertEquals(1, geo.findIntersections(ray).size());

	     //TC04 ray not intersect the geometries
	     ray = new Ray(new Point(6,2,2), new Vector(0,3,1));
	     assertNull(geo.findIntersections(ray));

	     //TC05 Empty body collection
	     ray = new Ray(new Point(6,2,2), new Vector(0,3,1));
	     assertNull(new Geometries().findIntersections(ray));
	 }

}
