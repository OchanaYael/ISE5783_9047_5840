/**
 * 
 */
package unittests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import primitives.Point;
import primitives.Vector;
/**
 * Unit tests for primitives.Point class
  * @author Yael ochana, sara mansur
 */
class PointTests {

	/**
	 * Test method for {@link primitives.Point#subtract(primitives.Point)}.
	 */
	@Test
	void testSubtract() 
	{
		Point p= new Point(2,0,0);
		assertEquals(p.subtract(new Point(1,0,1)), new Vector(1,0,-1), "The testSubtract function of a point does not sub correctly");
	}

	/**
	 * Test method for {@link primitives.Point#add(primitives.Point)}.
	 */
	@Test
	void testAdd() 
	{
		Point p= new Point(1,0,0);
		assertEquals(new Point(1,2,0), p.add(new Point(0,2,0)), "The add function of a point does not add correctly");	}

	/**
	 * Test method for {@link primitives.Point#distanceSquared(primitives.Point, primitives.Point)}.
	 */
	@Test
	void testDistanceSquared() 
	{
		Point p= new Point(2,1,1);
		assertEquals(p.distanceSquared(new Point(0,1,1)), 4, 0.00000001, "The DistanceSquared function of a point does not work correctly");
	}

	/**
	 * Test method for {@link primitives.Point#distance(primitives.Point, primitives.Point)}.
	 */
	@Test
	void testDistance() {
		Point p= new Point(2,1,1);
		assertEquals(p.distance(new Point(0,1,1)), 2, 0.00000001, "The Distance function of a point does not work correctly");
	}

}
