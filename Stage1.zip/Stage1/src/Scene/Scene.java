/**
 * 
 */
package Scene;
import lighting.LightSource;

import primitives.Color;

import java.util.LinkedList;
import java.util.List;

import geometries.Geometries;
import lighting.AmbientLight;

/**
 * Represents a scene in a 3D environment with geometries and lights.
 * It contains the name of the scene, the background color, the ambient light, geometries, and lights.
 * The class provides setters and getters for all of its fields.
 * The class is created by passing a name to its constructor.
 * @author yael_ochana
 * @author sara_mansur
 */
public class Scene {

    // Fields
	public String name;
	public Color background = Color.BLACK;
	public AmbientLight ambientLight = AmbientLight.NONE;
    public Geometries geometries = new Geometries();
    public List<LightSource> lights = new LinkedList<>();

    public double softSadow = 1;
    /**
     * Creates a new Scene object with the given name.
     * @param n the name of the scene
     */
    public Scene(String n) {
        this.name = n;
    }
    
    /**
     * builder set soft shadow
     * if the shadow will be soft.
     * @param softShadow - count of ray (if > 1 -> soft shadow on)
     * @return this (builder).
     */
    public Scene setSoftShadow(double softShadow) {
        if(softShadow <= 0)
            this.softSadow = 1;
        else
            this.softSadow = softShadow;
        return this;
    }

    // Setters

    /**
     * Sets the name of the scene.
     * @param _name the name to be set
     * @return the Scene object with the updated name
     */
    public Scene setName(String _name) {
        this.name = _name;
        return this;
    }

    /**
     * Sets the background color of the scene.
     * @param _color the color to be set
     * @return the Scene object with the updated background color
     */
    public Scene setBackground(Color _color) {
        this.background = _color;
        return this;
    }

    /**
     * Sets the ambient light of the scene.
     * @param _ambientLight the ambient light to be set
     * @return the Scene object with the updated ambient light
     */
    public Scene setAmbientLight(AmbientLight _ambientLight) {
        this.ambientLight = _ambientLight;
        return this;
    }

    /**
     * Sets the geometries of the scene.
     * @param _geometries the geometries to be set
     * @return the Scene object with the updated geometries
     */
    public Scene setGeometries(Geometries _geometries) {
        this.geometries = _geometries;
        return this;
    }

    /**
     * Sets the list of light sources in the scene.
     * @param lights the list of light sources to be set
     * @return the Scene object with the updated list of light sources
     */
    public Scene setLight(List<LightSource> lights) {
        this.lights = lights;
        return this;
    }

    /**
     * function adds lights in the scene
     * @param light light to add
     * @return this
     */
    public Scene addLight(LightSource light) {
        lights.add(light);
        return this;
    }

}