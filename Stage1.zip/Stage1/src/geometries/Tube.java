package geometries;

import static primitives.Util.isZero;

import java.util.List;

import primitives.Point;
import primitives.Ray;
import primitives.Util;
import primitives.Vector;

/** class Tube has one field: Ray
 * @author yael_ochana, sara_mansur */
public class Tube extends RadialGeometry  
{
	protected Ray exisRay;
    
    /** We will add a method to the interface that receives one parameter of type point and returns 
	   * @param p-point
	   * @param the normal vector perpendicular to the body at this point*/
	 @Override
     public Vector  getNormal(Point p)
     {
	   Point p0 = this.exisRay.getP0();
       Vector v = this.exisRay.getDir();
       if (p.equals(p0))
           return v;
       
       // projection of P-p0 on the ray:
       Vector u = p.subtract(p0);
       
       double t = Util.alignZero(u.dotProduct(v));
       // if the point is at a base
       
       if (p.equals(p0) || p.equals(p0.add(v))) 
           // if the point is at either base of the infinite cylinder
           return v;
       
       if(isZero(u.dotProduct(v)))
    		   throw new IllegalArgumentException("Tube's normal is not orthogonal to one of the point.");
    	  
       //the other point on the axis facing the given point
       Point o = p0.add(v.scale(t));
       return p.subtract(o).normalize();
}
    
   public Tube(double radius, Ray r) 
   {
		super(radius);
		this.exisRay= r;
	}
   
   /**
    * Finds the intersection points between this object and the given ray.
    *
    * @param ray The ray to find the intersection points with.
    * @return A list of intersection points between this object and the given ray.
    */
   @Override
   protected List<GeoPoint> findGeoIntersectionsHelper(Ray ray) {
       return null;
   }

   
   

  

}
