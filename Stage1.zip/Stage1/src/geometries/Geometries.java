package geometries;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import primitives.Point;
import primitives.Ray;

/**
 * class geometries
 * @author yael_ochana and sara_mansur
 */

public class Geometries extends Intersectable
{
    // A list to hold all the intersectable shapes
    List<Intersectable> intersectable = null;
    
    // A default constructor that initializes the intersectable list as a linked list
    public Geometries() {
        intersectable = new LinkedList<>();
    }
    
    // A constructor that takes an array of Intersectable objects and adds them to the intersectable list
    public Geometries(Intersectable... geometries ) 
    {
        intersectable = new LinkedList<>();
        add(geometries);
    }
    
    // A method that takes an array of Intersectable objects and adds them to the intersectable list
    public void add(Intersectable... geometries) 
    {
    	//intersectable.addAll(Arrays.asList(geometries));  
    	Collections.addAll(this.intersectable, geometries);
    }
    
    /**
     * Finds the intersection points between this object and the given ray.
     *
     * @param ray The ray to find the intersection points with.
     * @return A list of intersection points between this object and the given ray.
     */
 
    @Override
    public List<GeoPoint> findGeoIntersectionsHelper(Ray ray) {
        List<GeoPoint> result = null; // Initialize the result list

        // Iterate over each intersectable item
        for (Intersectable item : intersectable) {
            List<GeoPoint> itemList = item.findGeoIntersectionsHelper(ray); // Find intersections for the current item

            // If intersections are found
            if (itemList != null) {
                if (result == null) {
                    result = new LinkedList<>(); // Initialize the result list if it's null
                }
                result.addAll(itemList); // Add the intersections to the result list
            }
        }

        return result; // Return the result list
    }

    
}
