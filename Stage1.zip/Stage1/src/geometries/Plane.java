package geometries;

import java.util.List;

import primitives.Point;
import primitives.Ray;
import primitives.Util;
import primitives.Vector;

/** class Plane has two fields Point,Vector
 * @author yael ochana, sara mansur */

public class Plane extends Geometry
{
 
   Point p0;
   Vector normal;
   
   public Vector getNormal() 
   {
 		return normal;
 	}
   
   /** Constructor to initialize Plane
    * @param p1 the first point
    * @param p2 the second point
    * @param p3 the third point*/
   public Plane(Point p1, Point p2, Point p3)
   {
	   this.p0=p1;
       ///throw exception if there is identical point
       if(p1.equals(p2)||p2.equals(p3)||p1.equals(p3))
           throw new IllegalArgumentException("two of the point are the same");
       Vector v1 = p2.subtract(p1);
       Vector v2 = p3.subtract(p1);
       
       ///throw exception if there is linear dependence between the vectors
       if(v1.normalize().equals(v2.normalize()))
           throw new IllegalArgumentException("there is a linear dependence between the vectors");

       Vector n = v1.crossProduct(v2);
       this.normal=n.normalize();
   }

   /** Constructor to initialize Plane
    * @param p - point
    * @param v-vector*/
   public Plane (Point p, Vector v)
   {
	   p0 = p;
	   normal = v.normalize();
   }
   
   /** We will add a method to the interface that receives one parameter of type point and returns 
	   * @param p-point
	   * @param the normal vector perpendicular to the body at this point*/
    public Vector  getNormal(Point p)
    {
    	return normal;
    }

    /**
     * Finds the intersection points between this object and the given ray.
     *
     * @param ray The ray to find the intersection points with.
     * @return A list of intersection points between this object and the given ray.
     */
    @Override
    public List<GeoPoint> findGeoIntersectionsHelper(Ray ray){

        // q0=p0 = starting point of the ray
        if(p0.equals(ray.getP0()))
            return null;

        // Calculating the numerator.
        Vector p0_q0 = p0.subtract(ray.getP0());
        double numerator= Util.alignZero( normal.dotProduct(p0_q0));

        // In case that the plane contains the ray or is parallel to it.
        if(Util.isZero(numerator))
            return null;

        // Calculating the denominator
        double denominator = Util.alignZero(normal.dotProduct(ray.getDir()));

        // In case that the plane is parallel to it.
        if(Util.isZero(denominator))
            return null;

        double t = Util.alignZero(numerator / denominator);

        // The ray is pointing away from the plane.
        if (t<=0)
            return null;

        return List.of(new GeoPoint(this,ray.getPoint(t)));
    }


}
