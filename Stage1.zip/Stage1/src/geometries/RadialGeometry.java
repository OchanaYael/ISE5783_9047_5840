package geometries;

/** class RadialGeometry has one field radius
 * @author yael ochana, sara mansur */

abstract public class RadialGeometry extends Geometry 
{
     protected double radius;
     
     /** Constructor to initialize RadialGeometry
      * @param r -  radius*/
     RadialGeometry(double r)
     {
    	 this.radius=r;
     }
}
