package geometries;

import java.util.ArrayList;
import java.util.List;

import primitives.Point;
import primitives.Ray;
import primitives.Util;
import primitives.Vector;
/** Cylinder class has one field double:height
 * @author yael_ochana, sara_mansur */

public class Cylinder extends Tube 
{

//		double height;
//	    
//	   /** We will add a method to the interface that receives one parameter of type point and returns 
//		   * @param p-point
//		   * @param the normal vector perpendicular to the body at this point*/
//		 public Vector getNormal(Point point) {
//		        Point p0 = this.exisRay.getP0();
//		        Vector v = this.exisRay.getDir();
//
//		        if (point.equals(p0))
//		            return v;
//
//		        // projection of P-p0 on the ray:
//		        Vector u = point.subtract(p0);
//
//		        // distance from p0 to the o who is in from of point
//		        double t = Util.alignZero(u.dotProduct(v));
//
//		        // if the point is at a base
//		        if (t == 0 || Util.isZero(height - t))
//		            return v;
//
//		        //the other point on the axis facing the given point
//		        Point o = p0.add(v.scale(t));
//
//		        return point.subtract(o).normalize();
//		    }
//		
//		 /** constructor
//		   * @param radius
//		   * @param r - ray
//		   * @param h - height*/
//	    public Cylinder(double radius, Ray r, double h) 
//	    {
//		super(radius,r);
//		this.height=h;
//		// TODO Auto-generated constructor stub
//	    }
	final private double height;

    /**
     * Constructor for Cylinder
     *
     * @param axisRay central ray of Cylinder
     * @param radius  radius value
     * @param height  height value
     */
    public Cylinder(Ray axisRay, double radius, double height) {
        super(radius, axisRay);
        this.height = height;
    }

    /**
     * getter function for height
     *
     * @return height
     */
    public double getHeight() {
        return height;
    }

    @Override
    public boolean equals(Object obj) {
        return (obj instanceof Cylinder) &&
                super.equals(obj)&&  this.height == ((Cylinder) obj).height;
    }



    @Override
    public Vector getNormal(Point point) {
        //  checks if it in the bases center to avoid zero vector
        if( point.equals(this.exisRay.getP0() ) ||
                point.equals(this.exisRay.getP0().add(this.exisRay.getDir().scale(height)) ) ){
            return  this.exisRay.getDir() ;
        }
        // checks if it is in the bases and if it is it returbns axsix dir and if it not calc like tube
        double radiusSquared = this.radius * this.radius;
        Vector toOtherBase = this.exisRay.getDir().scale(this.height) ;
        Point p0Ver2 = this.exisRay.getP0().add(toOtherBase);
        double crossProduct01 =  this.exisRay.getDir().dotProduct(this.exisRay.getP0().subtract(point));
        double crossProduct02 =   this.exisRay.getDir().dotProduct(p0Ver2.subtract(point));
        return  (point.distanceSquared(this.exisRay.getP0()) <= radiusSquared  && crossProduct01  == 0) ||
                (point.distanceSquared(p0Ver2) <= radiusSquared && crossProduct02 == 0) ?
                this.exisRay.getDir() :
                super.getNormal(point) ;
    }

    @Override
    public List<Point> findIntersections(Ray ray) {
        return null;
    }

    @Override
    public List<GeoPoint> findGeoIntersectionsHelper(Ray ray) {

        List<GeoPoint> res = new ArrayList<>();
        List<GeoPoint> lst = super.findGeoIntersectionsHelper(ray);
        if (lst != null)
            for (GeoPoint geoPoint : lst) {
                double distance = Util.alignZero(geoPoint.point.subtract(this.exisRay.getP0()).dotProduct(this.exisRay.getDir()));
                if (distance > 0 && distance <= height)
                    res.add(geoPoint);
            }

        if (res.size() == 0)
            return null;
        return res;
    }
}
