package geometries;


import primitives.Color;
import primitives.Material;
import primitives.Point;
import primitives.Vector;

/** interface Geometry has one function
 * @author yael_ochana, sara_mansur */

public abstract class Geometry extends Intersectable {
    
    protected Color emission = Color.BLACK; // The emission color of the geometry
    
    private Material material = new Material(); // The material of the geometry
    
    /**
     * Abstract method that returns the normal vector perpendicular to the body at a given point.
     *
     * @param p The point for which to calculate the normal vector
     * @return The normal vector at the given point
     */
    public abstract Vector getNormal(Point p);
    
    /**
     * Sets the emission color of the geometry.
     *
     * @param emission The emission color to set
     * @return The modified Geometry object
     */
    public Geometry setEmission(Color emission) {
        this.emission = emission;
        return this;
    }
    
    /**
     * Returns the emission color of the geometry.
     *
     * @return The emission color of the geometry
     */
    public Color getEmission() {
        return this.emission;
    }
    
    /**
     * Sets the material of the geometry.
     *
     * @param material The material to set
     * @return The modified Geometry object
     */
    public Geometry setMaterial(Material material) {
        this.material = material;
        return this;
    }
    
    /**
     * Returns the material of the geometry.
     *
     * @return The material of the geometry
     */
    public Material getMaterial() {
        return this.material;
    }
}
