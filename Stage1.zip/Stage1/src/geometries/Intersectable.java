/**
 * The Intersectable interface represents a geometric object that can be intersected by a ray in 3D space.
 * Classes that implement this interface should provide a way to find the intersection points between themselves and a given ray.
 */

package geometries;

import primitives.Ray;

import java.util.List;

import primitives.Point;

public abstract class Intersectable 
{

   public static class GeoPoint {
	    /**
	     * The geometry associated with the point.
	     */
	    public Geometry geometry;

	    /**
	     * The point in space.
	     */
	    public Point point;
	    
	    @Override
	    public boolean equals(Object o) {
	        if (this == o) return true;
	        if (o == null || getClass() != o.getClass()) return false;
	        GeoPoint geoPoint = (GeoPoint) o;
	        return this.geometry.equals(geoPoint.geometry) && this.point.equals(geoPoint.point);
	    }
	    
	    /**
	     * constructor
	     */
	    public GeoPoint(Geometry geometry, Point point){
            this.geometry = geometry;
            this.point = point;
        }

		@Override
	    public String toString() {
	 	    return "geometry [geometry=" + geometry +" point="+ point + "]";
	    }
	}
   
   /**
    * find intersection points from specific Ray
    * @param ray the ray crossing the geometric object
    * @return immutable List of intersection points
    */
   public List<Point> findIntersections(Ray ray) {
        // Find the geometric intersections between the ray and the geometry
        List<GeoPoint> geoList = findGeoIntersections(ray);
        
        // If no intersections are found, return null
        if (geoList == null) {
            return null;
        } else {
            // Map the GeoPoint objects to their corresponding points and return as a list
            return geoList.stream().map(gp -> gp.point).toList();
        }
    }

    public final List<GeoPoint> findGeoIntersections1(Ray ray) {
        // Delegate the call to the findGeoIntersections method
        return findGeoIntersections(ray);
    }

    public final List<GeoPoint> findGeoIntersections(Ray ray) {
        // Delegate the call to the findGeoIntersectionsHelper method
        return findGeoIntersectionsHelper(ray);
    }


   /**
    *
    * @param ray ray intersecting the geometry
    * @param maxDistance maxximum distance to loook for intersections geometries
    * @return list of intersection points
    */
   protected abstract List<GeoPoint> findGeoIntersectionsHelper(Ray ray);


}
