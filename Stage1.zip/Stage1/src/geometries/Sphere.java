
package geometries;

import java.util.List;


import primitives.Point;
import primitives.Ray;
import primitives.Util;
import primitives.Vector;
 
/** class Sphere has one field Point
 * @author yael_ochana, sara_mansur */

public class Sphere extends RadialGeometry
{
    Point center;
    
    /** We will add a method to the interface that receives one parameter of type point and returns 
       * @param p-point
       * @param the normal vector perpendicular to the body at this point*/
  public Vector  getNormal(Point p)
  {
      //Checking whether the point is on the sphere:
      //if(p.distance(center) > radius)
          //throw new IllegalArgumentException("The point is not on the sphere.");
      
      //Checking whether the point is the same as the center point:
      if(center.equals(p))
          throw new IllegalArgumentException("The point is the same as the center point.");
      
      Vector v = p.subtract(center);
        return v.normalize();
  }
  
  public Sphere(double r , Point c) 
  {
        super(r);
        // TODO Auto-generated constructor stub
        this.center = c;
    }
  

  /**
   * Finds the intersection points between this object and the given ray.
   *
   * @param ray The ray to find the intersection points with.
   * @return A list of intersection points between this object and the given ray.
   */
  @Override
  public List<GeoPoint> findGeoIntersectionsHelper(Ray ray) {

      // p0 = center , returns 1 point
      if (ray.getP0().equals(center))
          return List.of(new GeoPoint(this,center.add(ray.getDir().scale(radius))));

      Vector u = center.subtract(ray.getP0());
      double tm = Util.alignZero(ray.getDir().dotProduct(u));

      double d_squared = Util.alignZero((u.lengthSquared() - tm * tm));
      double rr = radius * radius;

      // there are no intersections
      if (d_squared >= (rr))
          return null;

      double th = Util.alignZero((Math.sqrt(rr - d_squared)));
      double t1 = Util.alignZero(tm + th);
      double t2 = Util.alignZero(tm - th);

      // both are in same direction of sphere
      if (t1 > 0 && t2 > 0) {
          //  Point p1 = ray.getP0().add(ray.getDir().scale(t1));
          //Point p2 = ray.getP0().add(ray.getDir().scale(t2));

          return List.of(new GeoPoint(this,ray.getPoint(t1)),new GeoPoint(this, ray.getPoint(t2)));
      }

      if (t1 > 0) {
          //  Point p1 = ray.getP0().add(ray.getDir().scale(t1));
          return List.of(new GeoPoint(this,ray.getPoint(t1)));
      }

      if (t2 > 0) {
          // Point p2 = ray.getP0().add(ray.getDir().scale(t2));
          return List.of(new GeoPoint(this,ray.getPoint(t2)));
      }
      return null;
  }
		  
}
 
