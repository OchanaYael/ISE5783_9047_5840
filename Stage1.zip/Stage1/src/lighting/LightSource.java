/**
 * This is the package declaration for the 'lighting' package.
 */
package lighting;

import primitives.Color;
import primitives.Point;
import primitives.Vector;

/**
 * This interface represents a light source.
 * It provides methods to retrieve the intensity and direction of the light at a given point.
 * Authors: yael_ochana, sara_mansur
 */
public interface LightSource {

    /**
     * Retrieves the intensity of the light at a given point.
     * 
     * @param p The point at which the intensity is evaluated.
     * @return The intensity of the light at the given point.
     */
    public Color getIntensity(Point p);

    /**
     * Retrieves the direction of the light at a given point.
     * 
     * @param p The point at which the direction is evaluated.
     * @return The direction of the light at the given point.
     */
    public Vector getL(Point p);
    
    double getDistance(Point point);

}
