/**
 * 
 */
package lighting;

import primitives.Color;
import primitives.Double3;
import primitives.Point;
import primitives.Vector;

/**
 * @author  yael_ochana, sara_mansur
 *
 */
public class PointLight extends Light implements LightSource {
	
	private final Point position;
    private Double Kc = 1.0;
    private Double Kl = 0.0;
    private Double Kq = 0.0;
	
	public PointLight(Color intensity, Point position) {
		super(intensity);
		this.position = position;
	}
	
	/**
     * @param p Point that we want to know the intensity
     * @return Intensity of point light
     * Intensity(p) = Intensity_base / (Kc + Kl * d + Kq * d^2)
     */
    @Override
    public Color getIntensity(Point p) {
        double dSquared = p.distanceSquared(position);
        double d = Math.sqrt(dSquared);

        return (getIntensity().reduce(Kc + d * 	Kl + Kq* dSquared));

    }

    /**
     * L = normalize(point - position)
     */
    @Override
    public Vector getL(Point point) {
        return point.subtract(position).normalize(); // Calculate the direction vector from the light source position to the given point and normalize it
    }


	/**
	 * @param kc the kc to set
	 */
	public PointLight setKc(Double kc) {
		this.Kc = kc;
		return this;
	}

	/**
	 * @param kl the kl to set
	 */
	public PointLight setKl(Double kl) {
		this.Kl = kl;
		return this;
	}

	/**
	 * @param kq the kq to set
	 */
	public PointLight setKq(Double kq) {
		this.Kq = kq;
		return this;
	}
	
	@Override
    public double getDistance(Point point) {
        return point.distance(this.position);
    }

}
