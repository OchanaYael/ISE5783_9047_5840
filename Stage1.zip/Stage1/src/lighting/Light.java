
/**
 * @author yael_ochana, sara_mansur
 *
 */

/**
 * This is the abstract base class for different types of lights in a lighting system.
 * It contains a private field for intensity and provides a method to get the intensity.
 */
package lighting;

import primitives.Color;

/**
 * The Light class represents a light source in a lighting system.
 * It is an abstract class that cannot be instantiated directly.
 * It provides a constructor to set the intensity of the light and a method to get the intensity.
 * @author  yael_ochana, sara_mansur
 */
abstract class Light {
	 
	 private Color intensity; // The intensity of the light
	 
	 /**
	  * Constructs a light with the specified intensity.
	  * 
	  * @param intensity the color intensity of the light
	  */
	 protected Light(Color intensity) {
		 this.intensity = intensity;
	 }
	 
	 /**
	  * Returns the intensity of the light.
	  * 
	  * @return the color intensity of the light
	  */
	 public Color getIntensity() {
		 return this.intensity;
	 }
	 
	 

}
