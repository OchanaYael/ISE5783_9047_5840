
/**
 * @author yael_ochana, sara_mansur
 *
 */

package lighting;

import primitives.Color;
import primitives.Double3;

/**
 * The AmbientLight class represents ambient light in a lighting system.
 * It is a type of light that provides a uniform level of illumination throughout the scene.
 * It extends the Light class.
 */
public class AmbientLight extends Light {
	
	/**
	 * Constructs an AmbientLight with the specified color intensity and coefficient.
	 * The intensity is calculated by multiplying the color intensity (Ia) by the coefficient (Ka).
	 * 
	 * @param Ia the color intensity of the light
	 * @param Ka the coefficient determining the strength of the ambient light
	 */
	public AmbientLight(Color Ia, Double3 Ka){
		super(Ia.scale(Ka));
	}
    
	/**
	 * Constructs an AmbientLight with the specified color intensity and coefficient.
	 * The intensity is calculated by multiplying the color intensity (Ia) by the coefficient (Ka).
	 * 
	 * @param Ia the color intensity of the light
	 * @param Ka the coefficient determining the strength of the ambient light
	 */
	public AmbientLight(Color Ia, Double Ka){
		super(Ia.scale(Ka));
	}
	
	/**
	 * Constructs a default AmbientLight with no color intensity.
	 * The intensity is set to Color.BLACK.
	 */
	public AmbientLight() {
		super(Color.BLACK);
	}

	/**
	 * A constant representing no ambient light.
	 * The intensity is set to Color.BLACK and the coefficient to Double3.ZERO.
	 */
	public static final AmbientLight NONE = new AmbientLight(Color.BLACK, Double3.ZERO);
}
