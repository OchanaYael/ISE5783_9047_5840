
package lighting;

import primitives.Color;
import primitives.Point;
import primitives.Vector;

/**
 * DirectionalLight represents a light source that emits light uniformly in a specific direction.
 * It extends the Light class and implements the LightSource interface.
 */
public class DirectionalLight extends Light implements LightSource {
    
    private final Vector direction; // The direction of the light

    /**
     * Constructs a DirectionalLight object with the given intensity and direction.
     *
     * @param intensity The intensity of the light
     * @param direction The direction of the light
     * @author  yael_ochana, sara_mansur
     */
    public DirectionalLight(Color intensity, Vector direction) {
        super(intensity);
        this.direction = direction.normalize(); // Normalize the direction vector
    }

    /**
     * Returns the intensity of the light at the given point.
     * Since a directional light emits light uniformly, the intensity is the same at all points.
     *
     * @param point The point at which to calculate the intensity (not used in this implementation)
     * @return The intensity of the light
     */
    @Override
    public Color getIntensity(Point point) {
        return getIntensity();
    }

    /**
     * Returns the direction from the light source to the given point.
     * For a directional light, the direction is constant and does not depend on the point.
     *
     * @param point The point for which to calculate the direction (not used in this implementation)
     * @return The direction of the light
     */
    @Override
    public Vector getL(Point point) {
        return direction.normalize();
    }

	@Override
    public double getDistance(Point point) {
        return Double.POSITIVE_INFINITY;
    }
}
