/**
 * 
 */
package lighting;

import primitives.Color;
import primitives.Point;
import primitives.Vector;

/**
 * @author  yael_ochana, sara_mansur
 *
 */
public class SpotLight extends PointLight{
	
	private final Vector direction;
	
	public SpotLight(Color intensity, Point position, Vector direction) {
		super(intensity, position);
		this.direction = direction.normalize();
	}
	
	/**
     * @param p Point that we want to know the intensity
     * @return Color
     * Intensity(p) = Intensity_base * max(0, dotProduct(L, direction))
     */

	@Override
	public Color getIntensity(Point p) {
	    Vector l = getL(p); // Obtain the direction vector from the light source position to the given point
	    double d = l.dotProduct(this.direction); // Calculate the dot product between the direction vector and the light source's direction
	    
	    return super.getIntensity(p).scale(Math.max(0, d)); // Scale the base intensity of the light source by the maximum of 0 and the dot product value
	}

}
