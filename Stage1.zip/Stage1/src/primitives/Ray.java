package primitives;
import geometries.Intersectable.GeoPoint;
import java.util.List;

/** class Ray has two fields: Point, Vector.
 * @author yael ochana, sara mansur */
public class Ray 
{
   final Point p0;
   final Vector dir;
   
   /**
    * DELTA value to move the point away from original point
    */
   private static final double DELTA = 0.1;
   
   /** Constructor to initialize ray 
    * @param p, point 
    * @param v , vector*/
   public Ray (Point p, Vector v)
   {
	   p0 = p;
	   dir = v.normalize();
   }
   
   /**
    * Constructor for ray deflected by DELTA
    *
    * @param p origin
    * @param n   normal vector
    * @param dir direction
    */
   public Ray(Point p, Vector n, Vector dir) {
       this.dir = dir.normalize();
       double nv = n.dotProduct(this.dir);
       Vector delta  =n.scale(DELTA);
       if (nv < 0)
          delta = delta.scale(-1);
       this.p0 = p.add(delta);
   }

   public Point getP0() 
   {
	   return p0;
   }

   public Vector getDir() 
   {
	   return dir;
   }

   @Override
    public String toString() 
   {
	    return "Ray [p0=" + p0 + ", dir=" + dir + "]";
   }
   
   @Override
   public boolean equals(Object obj) 
	{
	      if (this == obj) 
		      return true;
	      return (obj instanceof Ray other)&& this.p0.equals(other.p0)&& this.dir.equals(other.dir);}
   
   public Point findClosestPoint(List<Point> points) {
	   return points == null || points.isEmpty() ? null
	   : getClosestGeoPoint(points.stream().map(p -> new GeoPoint(null, p)).toList()).point;
	  }

   
   /**
    *TODO - notes
    * @param list
    * @return
    */

   public GeoPoint getClosestGeoPoint(List<GeoPoint> list){
       GeoPoint result=null;
       double closestDistance = Double.MAX_VALUE; // the biggest value

       /**
        * chack if list empty
        */
       if (list == null) {
           return null;
       }

       for (GeoPoint p : list) {
    	   double temp = p.point.distanceSquared(p0);
           if (temp < closestDistance) {
               closestDistance = temp;
               result = p;
           }
       }
       return result;

   }
   
   
   public Point getPoint(double delta) {
       if (Util.isZero(delta)) {
           return p0;
       }
       return p0.add(dir.scale(delta));
   }
   
   
}
