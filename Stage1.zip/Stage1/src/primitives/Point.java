package primitives;


/** class Point has one Double3
 * @author yael ochana, sara mansur */
public class Point 
{
  public final Double3 xyz;
  
  public static final Point ZERO = new Point(Double3.ZERO);

  /** Constructor to initialize Point 
   * @param x the first coordinate
   * @param y the second coordinate
   * @param z the third coordinate*/
  public Point (double x, double y ,double z) 
  {
	  this.xyz= new Double3(x,y,z);
  }
  
  /** Constructor to initialize Point based Double3
   * @param d*/
  Point(Double3 d)
  { 
	  this.xyz=d;
  }
  
  /**
   * @param direction - direction
   * @param t -  the distance to add the point.
   * @return a point that is at a distance of 't' from the point in the direction of a specific vector.
   */
  public Point getPoint(Vector direction , double t) {
      try {
          return this.add(direction.scale(t));
      }
      catch (Exception e){
          return this;
      }
  }
  
/** method that sub tow points
   * @param p second point
   * @return vector */
  public Vector subtract(Point p) 
  {
	  return new Vector(xyz.subtract(p.xyz));
  }
  
  @Override
 public String toString() 
 {
	return "(" + xyz.d1 + ", " + xyz.d2 + ", " + xyz.d3 + ")";
 }
  
  @Override
  public boolean equals(Object obj) 
  {
      if (this == obj) 
	      return true;
      return (obj instanceof Point  other)&& this.xyz.equals(other.xyz);
  }


/** method that add point to this point
   * @param p second point
   * @return the result is Point */
  public Point add (Point p) 
  {
	 return new Point(p.xyz.add(this.xyz));
  }
  
  /** method that returns distance Squared between two points
   * @param p1 first point
   * @param p2 second point
   * @return the result is the distance Squared */
  public double distanceSquared (Point p2) 
  {
	  return (this.xyz.d1-p2.xyz.d1)*(this.xyz.d1-p2.xyz.d1)+ (this.xyz.d2-p2.xyz.d2)*(this.xyz.d2-p2.xyz.d2)+(this.xyz.d3-p2.xyz.d3)*(this.xyz.d3-p2.xyz.d3);
  }
  
  /** method that returns distance between two points
   * @param p1 first point
   * @param p2 second point
   * @return the result is the distance */
  public double distance(Point p2) 
  {
	  return Math.sqrt(this.distanceSquared (p2) );
  }
}
