package primitives;

/** class Vector
 * @author yael ochana, sara mansur */
public class Vector extends Point
{
	 /** Constructor to initialize Vector
	   * @param x the first coordinate
	   * @param y the second coordinate
	   * @param z the third coordinate*/
	  public Vector (double x, double y ,double z) 
	  {
		  super(x,y,z);
		  if(this.xyz == Double3.ZERO)
			  throw new IllegalArgumentException("Invalid input - zero vector");
	  }

	  
	  /** Constructor to initialize Vector based Double3
	   * @param d*/
	  Vector(Double3 d)
	  { 
		  super(d);
		  if(this.xyz.equals(Double3.ZERO))
		      throw new IllegalArgumentException("Invalid input - zero vector");
	  }
	  
	  /** method that add Vector to this Vector
	   * @param v second Vector
	   * @return the result is Vector */
	  public Vector add(Vector v) 
	  {
		  return new Vector(v.xyz.add(this.xyz));
	  }
	  
	  /**A method that multiplies a vector in a scalar
	   * @param d skalar
	   * @return the result is the new Vector */
	  public Vector scale(double d) 
	  {
		  return new Vector(this.xyz.scale(d));
	  }
	  
	  /** A method that performs a scalar multiplication
	   * @param v second Vector
	   * @return the result is the new Vector */
	  public double dotProduct(Vector v) 
	  {
		   return this.xyz.d1*v.xyz.d1+this.xyz.d2*v.xyz.d2+this.xyz.d3*v.xyz.d3;
	  }
	  
	  
	  /** A method that performs a vector multiplication between two vectors 
	   * @param v second Vector
	   * @return returns a vector perpendicular to both vectors */
	  public Vector crossProduct(Vector v) 
	  {
		  return new Vector(this.xyz.d2*v.xyz.d3-this.xyz.d3*v.xyz.d2,this.xyz.d3*v.xyz.d1-this.xyz.d1*v.xyz.d3,this.xyz.d1*v.xyz.d2-this.xyz.d2*v.xyz.d1);
	  }
	  
	  /** A method that calculates the squared length of the vector 
	   * @return the squared length of the vector*/
	  public double lengthSquared() 
	  {
		  return dotProduct(this) ;
	  }
	  
	  /** A method that calculates the length of the vector 
	   * @return the length of the vector*/
	  public double length() 
	  {
		  return Math.sqrt(lengthSquared()) ;
	  }

	  /** A method that normalizes a vector 
	   * @return a new normalized vector*/
	  public Vector normalize() 
	  {
		  return new Vector (this.scale(1/this.length()).xyz);
	  }

	 @Override
	 public String toString() 
	 {
		return super.toString();
	 }
	
	 @Override
	 public boolean equals(Object obj) 
	  {
	      if (this == obj) 
		      return true;
	      return (obj instanceof Vector other)&& this.xyz.equals(other.xyz);
	  }
} ;
