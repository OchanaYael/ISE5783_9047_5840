/**
 * 
 */
package renderer;
import java.util.List;

import Scene.Scene;
import primitives.Color;
import primitives.Ray;

/**
 * @author yael_ochana, sara_mansur
 *
 */
public abstract class RayTracerBase {
	protected Scene scene;
	
	/**
     * constructor for the ray tracer
     * @param scene to be intersected
     */
    public RayTracerBase(Scene scene) {
        this.scene = scene;
    }
    
    /**
     * abstract function to determine the color of a pixel
     * @param ray - ray to intersect
     * @return the color of the pixel intersects the given ray
     */
    public abstract Color traceRay(Ray ray);
    
    /**
     * function that traces rays and return average color of pixel
     * @param rays rays to trace
     */
    public abstract Color traceRays(List<Ray> rays);

}
