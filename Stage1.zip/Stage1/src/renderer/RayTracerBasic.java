/**
 * 
 */
package renderer;

import java.util.List;

import Scene.Scene;
import geometries.Intersectable.GeoPoint;
import lighting.LightSource;
import primitives.Color;
import primitives.Double3;
import primitives.Material;
import primitives.Point;
import primitives.Ray;
import primitives.Util;
import primitives.Vector;

/**
 * RayTracerBasic is a subclass of RayTracerBase that implements the basic ray tracing algorithm.
 * It calculates the color of a pixel based on the intersection of a ray with scene geometries and the lighting effects at that point.
 * The class provides methods for calculating the specular and diffusive components of the color.
 * The class also overrides the traceRay method of its superclass to find the closest intersection point with the ray and calculate the color of that point.
 * The class is created by passing a Scene object to its constructor.
 * @author yael_ochana
 * @author sara_munsur
 */
public class RayTracerBasic extends RayTracerBase {
	
	    private static final double DELTA = 0.1;
	    private static final int MAX_CALC_COLOR_LEVEL = 10;
	    private static final double INITIAL_K = 1.0;

	    private static final double MIN_CALC_COLOR_K = 0.001;
	    public RayTracerBasic(Scene scene)
	    {
	        super(scene);
	    }
	    
	    @Override
	    public Color traceRays(List<Ray> rays) {

	        Color color = Color.BLACK;
	        for (Ray ray : rays) {
	            color = color.add(traceRay(ray));
	        }
	        return color.reduce(rays.size());

	    }
	    /*
	     * Get color of the intersection of the ray with the scene
	     *
	     * @param ray Ray to trace
	     * @return Color of intersection
	     */
	    @Override
	    public Color traceRay(Ray ray) {
	        if (this.findClosestIntersection(ray) != null)
	            return calcColor(this.findClosestIntersection(ray), ray);
	        return scene.background;

	    }


	    private Color calcColor(GeoPoint intersection, Ray ray, int level, Double3 k) {
	        // Calculate local effect (ambient, diffuse, specular) at the intersection point
	        Color color = calcLocalEffect(intersection, ray.getDir(), k);
	        
	        // If we have reached the maximum recursion level, return the color without further calculations
	        if (1 == level) {
	            return color;
	        }
	        
	        // Calculate global effects (reflections, refractions) recursively
	        return color.add(calcGlobalEffects(intersection, ray.getDir(), level, k));
	    }

	    /*
	     * Calculate color using a recursive function.
	     *
	     * @param geopoint The point of intersection.
	     * @param ray      The ray.
	     * @return The color.
	     */
	    private Color calcColor(GeoPoint geopoint, Ray ray) {
	        // Calculate the color at the intersection point with maximum recursion level and initial k value
	        Color color = calcColor(geopoint, ray, MAX_CALC_COLOR_LEVEL, new Double3(INITIAL_K));
	        
	        // Add ambient light intensity to the calculated color
	        return color.add(scene.ambientLight.getIntensity());
	    }


	    private Color calcGlobalEffect(Ray ray, int level, Double3 kx, Double3 kkx) {
	        GeoPoint gp = findClosestIntersection(ray);

	        if (gp == null) {
	            return scene.background;
	        }

	        return calcColor(gp, ray, level - 1, kkx).scale(kx);
	    }
	    private Color calcGlobalEffects(GeoPoint intersection, Vector inRay, int level, Double3 k) {
	        Color color = Color.BLACK; //base color
	        Vector n = intersection.geometry.getNormal(intersection.point); //normal

	        //reflection attenuation of the material
	        Double3 kr = intersection.geometry.getMaterial().Kr;
	        //reflection level as affected by k
	        Double3 kkr = kr.product(k);

	        if (!kkr.lowerThan(MIN_CALC_COLOR_K)) { //if the reflection level is not lower than the minimum
	            //construct a reflection  ray from the point
	            Ray reflectedRay = constructReflectedRay(n, intersection.point, inRay);

	            //add this color to the point by recursively calling calcGlobalEffect
	            color = calcGlobalEffect(reflectedRay, level, kr, kkr);
	        }


	        //transparency  attenuation factor of the material
	        Double3 kt = intersection.geometry.getMaterial().Kt;
	        //transparency level
	        Double3 kkt = kt.product(k);

	        if (!kkt.lowerThan(MIN_CALC_COLOR_K)) {//if the transparency level is not lower than the minimum
	            //construct a refracted ray from the point
	            Ray refractedRay = constructRefractedRay(n, intersection.point, inRay);

	            //add to the color to the point by recursively calling calcGlobalEffect
	            color = color.add(calcGlobalEffect(refractedRay, level, kt, kkt));
	        }

	        return color;
	    }
	    
	    /*    //*
	     * help to calculate "calcColor" - calculated light contribution from all light
	     * sources
	     *
	     * @param intersection - point on geometry body
	     * @param ray          - ray from the camera
	     * @param kkt            - the current attenuation level
	     * @return calculated light contribution from all light sources
	     */
	        /*
	     * Calculate the local effect of light sources on a point
	     *
	     * @param intersection the point
	     * @param v            the direction of the ray from the viewer
	     * @param k            the kR or kT factor at this point
	     * @return the color
	     */
	    private Color calcLocalEffect(GeoPoint intersection, Vector v, Double3 k) {
	        Vector n = intersection.geometry.getNormal(intersection.point);

	        double nv = Util.alignZero(n.dotProduct(v)); //nv=n*v
	        if (Util.isZero(nv)) {
	            return Color.BLACK;
	        }

	        int nShininess = intersection.geometry.getMaterial().nShininess;
	        Double3 kd = intersection.geometry.getMaterial().Kd;
	        Double3 ks = intersection.geometry.getMaterial().Ks;

	        Color color = intersection.geometry.getEmission(); //base color

	        //for each light source in the scene
	        for (LightSource lightSource : scene.lights) {
	            Vector l = lightSource.getL(intersection.point); //the direction from the light source to the point
	            double nl = Util.alignZero(n.dotProduct(l)); //nl=n*l
	            //if sign(nl) == sign(nv) (if the light hits the point add it, otherwise don't add this light)
	            if (nl * nv > 0) {
	                //ktr is the level of shade on the point (according to transparency of material)
	                Double3 ktr = transparency(intersection, l, n,lightSource );
	                if (!(ktr.product(k)).lowerThan(MIN_CALC_COLOR_K)) {
	                    Color lightIntensity = lightSource.getIntensity(intersection.point).scale(ktr);
	                    color = color.add(calcDiffusive(kd, l, n, lightIntensity),
	                            calcSpecular(ks, l, n, v, nShininess, lightIntensity));
	                }
	            }
	        }
	        return color;
	    }
	      /*
	     * Returns wether a certain point is shaded by other objects
	     *
	     * @param gp          the point
	     * @param l           the direction of the light
	     * @param n           normal to the point
	     * @param lightSource the loght source
	     * @return true if the point is shaded
	     */
	      private boolean unshaded(GeoPoint gp, Vector l, Vector n, LightSource lightSource, double nv) {
	        Vector lightDirection = l.scale(-1); // Vector from the point to the light source
	        
	        Vector deltaVector = n.scale(nv < 0 ? DELTA : -DELTA); // Offset vector for shadow ray origin
	        Point p = gp.point.add(deltaVector); // Point offset by deltaVector
	        Ray lightRay = new Ray(p, lightDirection); // Shadow ray from the offset point towards the light source
	        
	        double lightDistance = lightSource.getDistance(gp.point); // Distance between the point and the light source
	        
	        // Finding only points that are closer to the point than the light
	        List<GeoPoint> intersections = scene.geometries.findGeoIntersections(lightRay);
	        
	        // If there are no intersections, return true (there is no shadow)
	        if (intersections == null) {
	            return true;
	        }
	        
	        // For each intersection
	        for (GeoPoint intersection : intersections) {
	            // If the material is not transparent, return false
	            if (intersection.geometry.getMaterial().Kt == Double3.ZERO) {
	                return false;
	            }
	        }
	        
	        // If no opaque surfaces are found, return true (there is no shadow)
	        return true;
	    }

	    /*
	     * calculate the specular light according to Phong's model
	     * @param ks - Coefficient for specular
	     * @param l - vector from light source
	     * @param n - normal to the point
	     * @param v - camera vector
	     * @param nShininess - exponent
	     * @param lightIntensity - Light intensity
	     * @return the specular light
	     */
	    private Color calcSpecular(Double3 ks, Vector l, Vector n, Vector v, int nShininess, Color lightIntensity) {
	        double ln = Util.alignZero(l.dotProduct(n)); //ln=l*n
	        Vector r = l.subtract(n.scale(2 * ln)).normalize(); //r=l-2*(l*n)*n
	        double vr = Util.alignZero(v.dotProduct(r)); //vr=v*r
	        double vrnsh = Math.pow(Math.max(0, -vr), nShininess); //vrnsh=max(0,-vr)^nshininess
	        return lightIntensity.scale(ks.scale(vrnsh)); //Ks * (max(0, - v * r) ^ Nsh) * Il
	    }

	    /*
	     * calculate the diffusive light according to Phong's model
	     * @param kd - Coefficient for diffusive
	     * @param l - vector from light source
	     * @param lightIntensity - Light intensity
	     * @return the diffusive light
	     */

	    private Color calcDiffusive(Double3 kd, Vector l, Vector n, Color lightIntensity) {
	        double ln = Util.alignZero(Math.abs(l.dotProduct(n))); //ln=|l*n|
	        return lightIntensity.scale(kd.scale(ln)); //Kd * |l * n| * Il
	    }

	    /*
	     * Construct the ray refracted by an intersection with the geometry
	     * @param n normal to the geometry at intersection
	     * @param point the intersection point
	     * @param innerVec the ray entering
	     * @return refracted ray (in our project there is no refraction incidence, so we return a new ray with the same characteristics)
	     */
	    private Ray constructRefractedRay(Vector n, Point point, Vector innerVec) {
	        return new Ray(point,n,innerVec);
	    }
	    /*
	     * Construct the ray getting reflected on an intersection point
	     * @param n normal to the point
	     * @param point the intersection point
	     * @param innerVec the ray entering at the intersection
	     * @return the reflected ray
	     */
	    private Ray constructReflectedRay(Vector n, Point point, Vector innerVec) {
	        //r = v - 2 * (v*n) * n
	        //r is the reflected ray
	        Vector r = null;
	        try {
	            r = innerVec.subtract(n.scale(innerVec.dotProduct(n)).scale(2)).normalize();
	        } catch (Exception e) {
	            return null;
	        }
	        return new Ray(point, n,r);
	    }
	    /*
	     * Find the closest intersection point between a ray base and the scene's geometries
	     * @param ray the ray
	     * @return the closest point
	     */
	    private GeoPoint findClosestIntersection(Ray ray) {
	        List<GeoPoint> geoPoints = scene.geometries.findGeoIntersections(ray);
	        return ray.getClosestGeoPoint(geoPoints);
	    }
	    /*
	     * The function returns the transparency of the point, which is the product of the transparency of the point's geometry
	     * and the transparency of all the geometries between the point and the light source
	     *
	     * @param gp The point on the geometry that we're currently shading.
	     * @param l the vector from the point to the light source
	     * @param n the normal vector of the point
	     * @param ls the light source
	     * @return The transparency of the point.
	     */
	    private Double3 transparency(GeoPoint gp, Vector l, Vector n, LightSource ls) {
	        Vector lightDir = l.scale(-1); // Vector from the point to the light source

	        // Calculate an epsilon vector based on the orientation of the normal and the light direction
	        Vector epsVector = n.scale(n.dotProduct(lightDir) > 0 ? DELTA : -DELTA);

	        Point point = gp.point.add(epsVector); // Point offset by the epsilon vector

	        Ray lightRay = new Ray(point, n, lightDir); // Ray from the offset point towards the light source

	        List<GeoPoint> intersections = scene.geometries.findGeoIntersections(lightRay); // Find intersections along the ray

	        Double3 ktr = new Double3(1); // Transparency coefficient initialized as 1 (fully transparent)

	        if (intersections != null) {
	            for (GeoPoint gp2 : intersections) {
	                // Check if the distance from the offset point to the intersection point is less than the light distance
	                if (point.distance(gp2.point) < ls.getDistance(point)) {
	                    // Multiply the transparency coefficient by the material's Kt (transparency) value
	                    ktr = gp2.geometry.getMaterial().Kt.product(ktr);
	                }
	            }
	        }

	        return ktr;
	    }

	}
